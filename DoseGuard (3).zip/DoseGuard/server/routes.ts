import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMedicineStatusSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get current medicine status
  app.get("/api/medicine-status", async (req, res) => {
    try {
      const status = await storage.getMedicineStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ message: "Failed to get medicine status" });
    }
  });

  // Mark medicine as given
  app.post("/api/medicine-status/mark-given", async (req, res) => {
    try {
      const status = await storage.markMedicineGiven();
      res.json(status);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark medicine as given" });
    }
  });

  // Reset medicine status (for daily reset)
  app.post("/api/medicine-status/reset", async (req, res) => {
    try {
      const status = await storage.resetMedicineStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ message: "Failed to reset medicine status" });
    }
  });

  // Update medicine status settings
  app.patch("/api/medicine-status", async (req, res) => {
    try {
      const updates = insertMedicineStatusSchema.partial().parse(req.body);
      const status = await storage.updateMedicineStatus(updates);
      res.json(status);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update medicine status" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
