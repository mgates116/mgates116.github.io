# Medicine Tracker Application

## Overview

This is a full-stack medicine tracking application built with React, Express, and TypeScript. The application helps track medication administration status for a patient named Lucy, featuring real-time status updates, browser notifications, and a clean medical-themed interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom medical theme colors
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API endpoints for medicine status management
- **Storage**: Currently using in-memory storage with an interface for future database integration
- **Middleware**: Custom request logging and error handling

### Data Storage Solutions
- **Current**: In-memory storage (MemStorage class) for development
- **Configured for**: PostgreSQL with Drizzle ORM
- **Database Schema**: Single table for medicine status tracking with fields for patient info, administration status, and timing
- **Migration Support**: Drizzle Kit for schema migrations

## Key Components

### Database Schema
```typescript
medicineStatus {
  id: varchar (primary key, default: "lucy_medicine")
  patientName: text (default: "Lucy")
  isGiven: boolean (default: false)
  lastGivenAt: timestamp (nullable)
  resetTime: text (default: "00:00", format: "HH:MM")
  notificationsEnabled: boolean (default: true)
}
```

### API Endpoints
- `GET /api/medicine-status` - Retrieve current medicine status
- `POST /api/medicine-status/mark-given` - Mark medicine as administered
- `POST /api/medicine-status/reset` - Reset daily medicine status
- `PATCH /api/medicine-status` - Update medicine status settings

### Frontend Features
- Real-time medicine status display
- One-click medicine administration tracking
- Browser notification system for reminders
- Responsive design with medical theme
- Toast notifications for user feedback
- Current time display

## Data Flow

1. **Initial Load**: Frontend queries medicine status via React Query
2. **Status Updates**: User actions trigger API calls with optimistic updates
3. **Notifications**: Browser notifications triggered based on medicine status
4. **Real-time Updates**: React Query automatically refetches data and updates UI
5. **Error Handling**: Toast notifications for API errors with fallback states

## External Dependencies

### Frontend Dependencies
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **wouter**: Lightweight routing
- **lucide-react**: Icon library
- **date-fns**: Date manipulation utilities

### Backend Dependencies
- **express**: Web framework
- **drizzle-orm**: TypeScript ORM
- **@neondatabase/serverless**: Neon database driver
- **drizzle-zod**: Schema validation integration
- **zod**: Runtime type validation

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type checking
- **tsx**: TypeScript execution
- **esbuild**: Production bundling

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations applied via `npm run db:push`

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string (required for production)
- `NODE_ENV`: Environment setting (development/production)

### Deployment Steps
1. Install dependencies with `npm install`
2. Set up database and configure `DATABASE_URL`
3. Run database migrations with `npm run db:push`
4. Build application with `npm run build`
5. Start production server with `npm start`

### Development Workflow
- `npm run dev`: Start development server with hot reload
- `npm run check`: TypeScript type checking
- `npm run db:push`: Apply database schema changes

The application is designed as a simple, single-patient medicine tracker with room for expansion to multiple patients and more complex medication schedules. The architecture supports easy database switching and feature additions through its modular design.