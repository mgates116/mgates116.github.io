import { type MedicineStatus, type InsertMedicineStatus } from "@shared/schema";

export interface IStorage {
  getMedicineStatus(): Promise<MedicineStatus | undefined>;
  updateMedicineStatus(status: Partial<InsertMedicineStatus>): Promise<MedicineStatus>;
  markMedicineGiven(): Promise<MedicineStatus>;
  resetMedicineStatus(): Promise<MedicineStatus>;
}

export class MemStorage implements IStorage {
  private medicineStatus: MedicineStatus;

  constructor() {
    // Initialize with default status
    this.medicineStatus = {
      id: "lucy_medicine",
      patientName: "Lucy",
      isGiven: false,
      lastGivenAt: null,
      resetTime: "00:00",
      notificationsEnabled: true,
    };
  }

  async getMedicineStatus(): Promise<MedicineStatus | undefined> {
    return this.medicineStatus;
  }

  async updateMedicineStatus(updates: Partial<InsertMedicineStatus>): Promise<MedicineStatus> {
    this.medicineStatus = { ...this.medicineStatus, ...updates };
    return this.medicineStatus;
  }

  async markMedicineGiven(): Promise<MedicineStatus> {
    this.medicineStatus = {
      ...this.medicineStatus,
      isGiven: true,
      lastGivenAt: new Date(),
    };
    return this.medicineStatus;
  }

  async resetMedicineStatus(): Promise<MedicineStatus> {
    this.medicineStatus = {
      ...this.medicineStatus,
      isGiven: false,
      lastGivenAt: null,
    };
    return this.medicineStatus;
  }
}

export const storage = new MemStorage();
