import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Clock, User, Bell, RotateCcw, Check, Settings } from "lucide-react";
import { useEffect, useState } from "react";
import type { MedicineStatus } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>("default");

  // Query for medicine status
  const { data: medicineStatus, isLoading } = useQuery<MedicineStatus>({
    queryKey: ["/api/medicine-status"],
  });

  // Mutation to mark medicine as given
  const markGivenMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/medicine-status/mark-given"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medicine-status"] });
      toast({
        title: "Medicine Marked as Given",
        description: "Lucy's medicine has been recorded as administered.",
      });
      // Stop notifications
      stopNotifications();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to mark medicine as given. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Mutation to reset status
  const resetMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/medicine-status/reset"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medicine-status"] });
      // Restart notifications if enabled
      if (notificationPermission === "granted") {
        startNotifications();
      }
    },
  });

  // Update current time every minute
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  // Check notification permission on mount
  useEffect(() => {
    if ("Notification" in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  // Set up daily reset
  useEffect(() => {
    const scheduleNextReset = () => {
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);
      
      const msUntilMidnight = tomorrow.getTime() - now.getTime();
      
      setTimeout(() => {
        resetMutation.mutate();
        scheduleNextReset(); // Schedule next reset
      }, msUntilMidnight);
    };

    scheduleNextReset();
  }, []);

  // Notification functionality
  const startNotifications = () => {
    if (!medicineStatus?.isGiven && notificationPermission === "granted") {
      // Send immediate notification
      new Notification("Medicine Reminder", {
        body: "Has Lucy had her medicine?",
        icon: "/favicon.ico",
        tag: "medicine-reminder",
      });

      // Set up recurring notifications every 30 minutes
      const notificationInterval = setInterval(() => {
        if (!medicineStatus?.isGiven) {
          new Notification("Medicine Reminder", {
            body: "Has Lucy had her medicine?",
            icon: "/favicon.ico",
            tag: "medicine-reminder",
          });
        } else {
          clearInterval(notificationInterval);
        }
      }, 30 * 60 * 1000); // 30 minutes

      // Store interval in localStorage for cleanup
      localStorage.setItem("notificationInterval", notificationInterval.toString());
    }
  };

  const stopNotifications = () => {
    const intervalId = localStorage.getItem("notificationInterval");
    if (intervalId) {
      clearInterval(parseInt(intervalId));
      localStorage.removeItem("notificationInterval");
    }
  };

  // Start notifications when status changes to pending
  useEffect(() => {
    if (medicineStatus && !medicineStatus.isGiven && notificationPermission === "granted") {
      startNotifications();
    } else if (medicineStatus?.isGiven) {
      stopNotifications();
    }
  }, [medicineStatus?.isGiven, notificationPermission]);

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === "granted") {
        toast({
          title: "Notifications Enabled",
          description: "You'll now receive medicine reminders.",
        });
        if (medicineStatus && !medicineStatus.isGiven) {
          startNotifications();
        }
      } else if (permission === "denied") {
        toast({
          title: "Notifications Blocked",
          description: "Please enable notifications in your browser settings.",
          variant: "destructive",
        });
      }
    }
  };

  const getTimeUntilReset = () => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    const msUntilMidnight = tomorrow.getTime() - now.getTime();
    const hours = Math.floor(msUntilMidnight / (1000 * 60 * 60));
    const minutes = Math.floor((msUntilMidnight % (1000 * 60 * 60)) / (1000 * 60));
    
    return { hours, minutes };
  };

  const timeUntilReset = getTimeUntilReset();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 font-roboto">
      <div className="min-h-screen flex flex-col items-center justify-start px-4 py-8">
        
        {/* Header */}
        <div className="w-full max-w-md mb-8 text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Medicine Tracker</h1>
          <p className="text-gray-600 text-sm">Keep track of Lucy's daily medication</p>
        </div>

        {/* Status Card */}
        <Card className="w-full max-w-md bg-white rounded-2xl shadow-lg mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div 
                  className={`w-4 h-4 rounded-full ${
                    medicineStatus?.isGiven 
                      ? 'bg-green-600' 
                      : 'pending-orange animate-pulse'
                  }`}
                />
                <span className="text-lg font-medium text-gray-800">
                  {medicineStatus?.isGiven ? 'Completed' : 'Pending'}
                </span>
              </div>
              <div className="text-sm text-gray-500 flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                <span>
                  {currentTime.toLocaleTimeString('en-US', { 
                    hour: 'numeric', 
                    minute: '2-digit',
                    hour12: true 
                  })}
                </span>
              </div>
            </div>

            {/* Patient Info */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center">
                  <User className="text-white text-lg" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">{medicineStatus?.patientName || 'Lucy'}</h3>
                  <p className="text-sm text-gray-600">Daily Medication</p>
                </div>
              </div>
            </div>

            {/* Question Prompt */}
            <div className="text-center mb-6">
              <p className="text-lg text-gray-700 font-medium">Has Lucy had her medicine?</p>
            </div>

            {/* Action Button */}
            <Button 
              className="w-full medical-green hover:medical-green-light text-white font-semibold py-4 px-6 rounded-xl transition-colors duration-200 flex items-center justify-center space-x-2 shadow-md hover:shadow-lg h-auto"
              onClick={() => markGivenMutation.mutate()}
              disabled={markGivenMutation.isPending || medicineStatus?.isGiven}
            >
              <Check className="text-xl" />
              <span className="text-lg">
                {markGivenMutation.isPending ? 'Recording...' : 'Done'}
              </span>
            </Button>
          </CardContent>
        </Card>

        {/* Notification Status */}
        <Card className="w-full max-w-md bg-white rounded-2xl shadow-lg mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Notifications</h3>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${
                  !medicineStatus?.isGiven && notificationPermission === 'granted' 
                    ? 'pending-orange animate-pulse' 
                    : 'bg-gray-400'
                }`} />
                <span className="text-sm text-gray-600">
                  {!medicineStatus?.isGiven && notificationPermission === 'granted' ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>
            
            <div className={`border-l-4 p-4 rounded-r-lg ${
              !medicineStatus?.isGiven && notificationPermission === 'granted'
                ? 'bg-orange-50 border-orange-400'
                : 'bg-gray-50 border-gray-400'
            }`}>
              <div className="flex items-start space-x-3">
                <Bell className={`mt-0.5 ${
                  !medicineStatus?.isGiven && notificationPermission === 'granted'
                    ? 'text-orange-600'
                    : 'text-gray-500'
                }`} />
                <div>
                  <p className={`text-sm font-medium ${
                    !medicineStatus?.isGiven && notificationPermission === 'granted'
                      ? 'text-orange-800'
                      : 'text-gray-700'
                  }`}>
                    {!medicineStatus?.isGiven && notificationPermission === 'granted' 
                      ? 'Reminder Active' 
                      : 'Reminders Paused'
                    }
                  </p>
                  <p className={`text-sm mt-1 ${
                    !medicineStatus?.isGiven && notificationPermission === 'granted'
                      ? 'text-orange-700'
                      : 'text-gray-600'
                  }`}>
                    {!medicineStatus?.isGiven && notificationPermission === 'granted'
                      ? "You'll receive notifications until medicine is marked as given"
                      : medicineStatus?.isGiven 
                        ? "Medicine completed - notifications stopped"
                        : "Enable notifications to receive reminders"
                    }
                  </p>
                </div>
              </div>
            </div>

            {/* Notification Controls */}
            <div className="mt-4 pt-4 border-t border-gray-100">
              <Button 
                variant="outline"
                className="w-full text-sm text-gray-600 hover:text-gray-800 py-2 px-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                onClick={requestNotificationPermission}
                disabled={notificationPermission === 'granted'}
              >
                <Settings className="w-4 h-4 mr-2" />
                {notificationPermission === 'granted' 
                  ? 'Notifications Enabled' 
                  : 'Enable Notifications'
                }
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Daily Reset Info */}
        <Card className="w-full max-w-md bg-white rounded-2xl shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">Daily Reset</h3>
              <RotateCcw className="w-5 h-5 text-gray-400" />
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Next Reset:</span>
                <span className="text-sm font-medium text-gray-800">12:00 AM</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Time Until Reset:</span>
                <span className="text-sm font-medium text-gray-800">
                  {timeUntilReset.hours}h {timeUntilReset.minutes}m
                </span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 rounded-full bg-blue-500 mt-1 flex-shrink-0" />
                <p className="text-xs text-gray-600">Status automatically resets to "Pending" at midnight each day</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-xs text-gray-500">Medicine Tracker v1.0</p>
        </div>

      </div>
    </div>
  );
}
