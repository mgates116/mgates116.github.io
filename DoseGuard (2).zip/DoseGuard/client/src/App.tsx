import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import HomeStatic from "@/pages/home-static";
import NotFound from "@/pages/not-found";

// Detect if running on GitHub Pages or static hosting
const isGitHubPages = window.location.hostname.includes('github.io') || 
                     !window.location.port; // No port usually means static hosting

function Router() {
  return (
    <Switch>
      <Route path="/" component={isGitHubPages ? HomeStatic : Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
