import type { MedicineStatus, InsertMedicineStatus } from "@shared/schema";

const STORAGE_KEY = "medicine-status";

const defaultStatus: MedicineStatus = {
  id: "lucy_medicine",
  patientName: "Lucy",
  isGiven: false,
  lastGivenAt: null,
  resetTime: "00:00",
  notificationsEnabled: true,
};

export class MedicineLocalStorage {
  getMedicineStatus(): MedicineStatus {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Convert lastGivenAt string back to Date if it exists
        if (parsed.lastGivenAt) {
          parsed.lastGivenAt = new Date(parsed.lastGivenAt);
        }
        return { ...defaultStatus, ...parsed };
      }
    } catch (error) {
      console.error("Error reading from localStorage:", error);
    }
    return defaultStatus;
  }

  updateMedicineStatus(updates: Partial<InsertMedicineStatus>): MedicineStatus {
    const current = this.getMedicineStatus();
    const updated = { ...current, ...updates };
    this.saveMedicineStatus(updated);
    return updated;
  }

  markMedicineGiven(): MedicineStatus {
    const current = this.getMedicineStatus();
    const updated = {
      ...current,
      isGiven: true,
      lastGivenAt: new Date(),
    };
    this.saveMedicineStatus(updated);
    return updated;
  }

  resetMedicineStatus(): MedicineStatus {
    const current = this.getMedicineStatus();
    const updated = {
      ...current,
      isGiven: false,
      lastGivenAt: null,
    };
    this.saveMedicineStatus(updated);
    return updated;
  }

  private saveMedicineStatus(status: MedicineStatus): void {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(status));
    } catch (error) {
      console.error("Error saving to localStorage:", error);
    }
  }
}

export const medicineStorage = new MedicineLocalStorage();