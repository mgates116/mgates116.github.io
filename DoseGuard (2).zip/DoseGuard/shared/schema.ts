import { pgTable, text, varchar, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const medicineStatus = pgTable("medicine_status", {
  id: varchar("id").primaryKey().default("lucy_medicine"),
  patientName: text("patient_name").notNull().default("Lucy"),
  isGiven: boolean("is_given").notNull().default(false),
  lastGivenAt: timestamp("last_given_at"),
  resetTime: text("reset_time").notNull().default("00:00"), // Format: "HH:MM"
  notificationsEnabled: boolean("notifications_enabled").notNull().default(true),
});

export const insertMedicineStatusSchema = createInsertSchema(medicineStatus).omit({
  id: true,
});

export type InsertMedicineStatus = z.infer<typeof insertMedicineStatusSchema>;
export type MedicineStatus = typeof medicineStatus.$inferSelect;
